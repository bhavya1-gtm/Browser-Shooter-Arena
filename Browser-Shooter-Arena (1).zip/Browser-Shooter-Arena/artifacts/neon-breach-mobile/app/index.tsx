import { Ionicons } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import { useEffect, useMemo, useRef, useState } from 'react';
import { PanResponder, Pressable, StyleSheet, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useColors } from '@/hooks/useColors';

type Phase = 'start' | 'playing' | 'over';
type EnemyKind = 'runner' | 'tank';
type Enemy = { id: number; kind: EnemyKind; x: number; y: number; hp: number; maxHp: number; hit: number };

const clamp = (value: number, min: number, max: number) => Math.max(min, Math.min(max, value));
const seeded = (seed: number) => {
  const value = Math.sin(seed * 12.9898 + 78.233) * 43758.5453;
  return value - Math.floor(value);
};

export default function MobileGame() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const [phase, setPhase] = useState<Phase>('start');
  const [wave, setWave] = useState(1);
  const [health, setHealth] = useState(100);
  const [ammo, setAmmo] = useState(12);
  const [score, setScore] = useState(0);
  const [combo, setCombo] = useState(1);
  const [status, setStatus] = useState('SYSTEM READY');
  const [enemies, setEnemies] = useState<Enemy[]>([]);
  const [player, setPlayer] = useState({ x: 50, y: 72 });
  const waveRef = useRef(1);
  const playerRef = useRef(player);
  const enemiesRef = useRef(enemies);
  const joystickStart = useRef({ x: 0, y: 0 });
  const fireTimer = useRef<ReturnType<typeof setInterval> | null>(null);
  const waveTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  playerRef.current = player;
  enemiesRef.current = enemies;

  const spawnWave = (nextWave: number) => {
    const count = Math.min(20, 5 + nextWave * 2);
    const wavePressure = Math.max(0, nextWave - 1);
    const tankChance = Math.min(0.55, 0.12 + wavePressure * 0.08);
    const nextEnemies = Array.from({ length: count }, (_, index) => {
      const kind: EnemyKind = nextWave > 1 && seeded(index * 17 + nextWave * 29) < tankChance ? 'tank' : 'runner';
      const maxHp = kind === 'tank' ? 118 + wavePressure * 24 : 52 + wavePressure * 9;
      const edge = index % 4;
      return {
        id: nextWave * 100 + index,
        kind,
        x: edge === 0 ? 12 + seeded(index + nextWave) * 76 : edge === 1 ? 88 : 12 + seeded(index * 4 + nextWave) * 76,
        y: edge === 0 ? 14 : edge === 1 ? 24 + seeded(index + nextWave * 3) * 52 : 14 + seeded(index * 6 + nextWave) * 25,
        hp: maxHp,
        maxHp,
        hit: 0,
      };
    });
    setEnemies(nextEnemies);
    enemiesRef.current = nextEnemies;
    setStatus(`WAVE ${String(nextWave).padStart(2, '0')} // THREAT ${Math.min(5, nextWave)}/5`);
  };

  const startRun = () => {
    if (waveTimer.current) clearTimeout(waveTimer.current);
    waveRef.current = 1;
    setPhase('playing');
    setWave(1);
    setHealth(100);
    setAmmo(12);
    setScore(0);
    setCombo(1);
    setPlayer({ x: 50, y: 72 });
    void Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    spawnWave(1);
  };

  const fire = () => {
    if (phase !== 'playing') return;
    if (ammo <= 0) {
      setStatus('MAGAZINE EMPTY // TAP RELOAD');
      void Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning);
      return;
    }
    setAmmo((value) => value - 1);
    const current = enemiesRef.current.filter((enemy) => enemy.hp > 0);
    if (!current.length) return;
    const nearest = current
      .map((enemy) => ({ enemy, distance: Math.hypot(enemy.x - playerRef.current.x, enemy.y - playerRef.current.y) }))
      .sort((a, b) => a.distance - b.distance)[0].enemy;
    const wavePressure = Math.max(0, waveRef.current - 1);
    const damage = (nearest.kind === 'tank' ? 30 : 42) + Math.min(15, wavePressure * 3);
    const nextHp = clamp(nearest.hp - damage, 0, nearest.maxHp);
    const nextEnemies = enemiesRef.current.map((enemy) => enemy.id === nearest.id ? { ...enemy, hp: nextHp, hit: Date.now() } : enemy);
    enemiesRef.current = nextEnemies;
    setEnemies(nextEnemies);
    setScore((value) => value + (nextHp === 0 ? 125 * combo : 12));
    if (nextHp === 0) {
      setCombo((value) => Math.min(9, value + 1));
      setStatus(`${nearest.kind === 'tank' ? 'TANK' : 'RUNNER'} NEUTRALIZED`);
      void Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    } else {
      setStatus(`IMPACT CONFIRMED // ${Math.ceil(nextHp)} HP REMAINING`);
      void Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
  };

  const reload = () => {
    if (phase !== 'playing' || ammo === 12) return;
    setAmmo(12);
    setStatus('MAGAZINE FULL // MOVE');
    void Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
  };

  useEffect(() => {
    if (phase !== 'playing') return;
    const tick = setInterval(() => {
      const currentPlayer = playerRef.current;
      const wavePressure = Math.max(0, waveRef.current - 1);
      const nextEnemies = enemiesRef.current
        .filter((enemy) => enemy.hp > 0)
        .map((enemy) => {
          const dx = currentPlayer.x - enemy.x;
          const dy = currentPlayer.y - enemy.y;
          const distance = Math.hypot(dx, dy);
          const speed = (enemy.kind === 'tank' ? 1.2 : 2.2) + wavePressure * 0.18;
          if (distance < 10) {
            setHealth((value) => {
              const nextHealth = Math.max(0, value - (enemy.kind === 'tank' ? 8 : 4) - Math.min(10, wavePressure * 2));
              if (nextHealth === 0) setPhase('over');
              return nextHealth;
            });
          }
          if (distance < 2) return { ...enemy, x: enemy.x, y: enemy.y };
          return { ...enemy, x: enemy.x + (dx / distance) * speed, y: enemy.y + (dy / distance) * speed };
        });
      enemiesRef.current = nextEnemies;
      setEnemies(nextEnemies);
      if (!nextEnemies.length && !waveTimer.current) {
        setStatus('SECTOR CLEAR // NEXT BREACH INBOUND');
        waveTimer.current = setTimeout(() => {
          waveTimer.current = null;
          const nextWave = waveRef.current + 1;
          waveRef.current = nextWave;
          setWave(nextWave);
          spawnWave(nextWave);
        }, 1800);
      }
    }, 700);
    return () => clearInterval(tick);
  }, [phase]);

  useEffect(() => () => {
    if (fireTimer.current) clearInterval(fireTimer.current);
    if (waveTimer.current) clearTimeout(waveTimer.current);
  }, []);

  const moveResponder = useMemo(() => PanResponder.create({
    onStartShouldSetPanResponder: () => true,
    onMoveShouldSetPanResponder: () => true,
    onPanResponderGrant: (event) => { joystickStart.current = { x: event.nativeEvent.pageX, y: event.nativeEvent.pageY }; },
    onPanResponderMove: (_, gesture) => {
      const dx = clamp(gesture.dx / 55, -1, 1);
      const dy = clamp(gesture.dy / 55, -1, 1);
      setPlayer((value) => ({ x: clamp(value.x + dx * 1.1, 8, 92), y: clamp(value.y + dy * 1.1, 12, 88) }));
    },
  }), []);

  const healthWidth = `${clamp(health, 0, 100)}%` as `${number}%`;
  return (
    <View style={[styles.root, { backgroundColor: colors.background }]}>
      <View style={[styles.arena, { paddingTop: insets.top + 12, paddingBottom: insets.bottom + 10 }]}>
        <View style={styles.grid} pointerEvents="none" />
        {phase === 'playing' && (
          <>
            <View style={styles.topHud}>
              <View><Text style={[styles.label, { color: colors.mutedForeground }]}>WAVE / CONTACTS</Text><Text testID="mobile-wave" style={[styles.hudValue, { color: colors.accent }]}>{String(wave).padStart(2, '0')} <Text style={styles.smallValue}>{enemies.length}</Text></Text></View>
              <View style={styles.centerHud}><Text style={[styles.label, { color: colors.mutedForeground }]}>COMBO</Text><Text testID="mobile-combo" style={[styles.hudValue, { color: '#a88dff' }]}>{combo}X</Text></View>
              <View style={styles.rightHud}><Text style={[styles.label, { color: colors.mutedForeground }]}>SCORE</Text><Text testID="mobile-score" style={[styles.hudValue, { color: colors.primary }]}>{score.toLocaleString()}</Text></View>
            </View>
            <View style={styles.minimap}><View style={[styles.minimapPlayer, { backgroundColor: colors.primary, left: `${player.x}%`, top: `${player.y}%` }]} />{enemies.map((enemy) => <View key={`map-${enemy.id}`} style={[styles.minimapEnemy, { backgroundColor: enemy.kind === 'tank' ? colors.accent : colors.destructive, left: `${enemy.x}%`, top: `${enemy.y}%` }]} />)}</View>
            {enemies.map((enemy) => (
              <View key={enemy.id} style={[styles.enemy, { left: `${enemy.x}%`, top: `${enemy.y}%`, borderColor: enemy.kind === 'tank' ? colors.accent : colors.destructive, backgroundColor: enemy.kind === 'tank' ? '#7d303c' : '#14665f', transform: [{ scale: enemy.hit && Date.now() - enemy.hit < 180 ? 1.12 : 1 }] }]}>
                <Ionicons name={enemy.kind === 'tank' ? 'shield' : 'flash'} size={18} color={colors.foreground} />
                <View style={styles.enemyBar}><View style={[styles.enemyFill, { backgroundColor: enemy.kind === 'tank' ? colors.accent : colors.primary, width: `${(enemy.hp / enemy.maxHp) * 100}%` }]} /></View>
              </View>
            ))}
            <View style={[styles.player, { left: `${player.x}%`, top: `${player.y}%`, borderColor: colors.primary }]}><Ionicons name="navigate" size={22} color={colors.primary} /></View>
            <View style={styles.crosshair}><View style={[styles.crosshairLine, { backgroundColor: colors.foreground }]} /><View style={[styles.crosshairLineVertical, { backgroundColor: colors.foreground }]} /></View>
            <View style={styles.bottomHud}><View style={styles.healthBlock}><View style={styles.healthRow}><Text style={[styles.label, { color: colors.mutedForeground }]}>SUIT INTEGRITY</Text><Text testID="mobile-health" style={[styles.healthText, { color: colors.foreground }]}>{health}%</Text></View><View style={[styles.healthTrack, { borderColor: colors.border }]}><View style={[styles.healthFill, { backgroundColor: health < 35 ? colors.destructive : colors.accent, width: healthWidth }]} /></View><Text testID="mobile-status" style={[styles.status, { color: colors.primary }]}>{status}</Text></View><View style={styles.ammoBlock}><Text testID="mobile-ammo" style={[styles.ammo, { color: colors.foreground }]}>{String(ammo).padStart(2, '0')}<Text style={styles.ammoMax}> / 12</Text></Text><Text style={[styles.label, { color: colors.accent }]}>KINETIC MAG</Text></View></View>
            <View style={styles.touchRow}>
              <View style={[styles.joystick, { borderColor: colors.border }]} {...moveResponder.panHandlers}><View style={[styles.joystickKnob, { backgroundColor: colors.primary }]} /></View>
              <View style={styles.actionCluster}><Pressable testID="mobile-reload" onPress={reload} style={({ pressed }) => [styles.iconButton, { backgroundColor: colors.secondary, borderColor: colors.border, opacity: pressed ? .65 : 1 }]}><Ionicons name="reload" size={20} color={colors.primary} /></Pressable><Pressable testID="mobile-jump" onPress={() => void Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light)} style={({ pressed }) => [styles.iconButton, { backgroundColor: colors.secondary, borderColor: colors.border, opacity: pressed ? .65 : 1 }]}><Ionicons name="arrow-up" size={20} color={colors.primary} /></Pressable><Pressable testID="mobile-fire" onPressIn={() => { fire(); fireTimer.current = setInterval(fire, 180); }} onPressOut={() => { if (fireTimer.current) clearInterval(fireTimer.current); fireTimer.current = null; }} style={({ pressed }) => [styles.fireButton, { backgroundColor: colors.destructive, opacity: pressed ? .7 : 1 }]}><Ionicons name="radio-button-on" size={26} color={colors.foreground} /></Pressable></View>
            </View>
          </>
        )}
        {phase === 'start' && <View style={[styles.card, { borderColor: colors.border, backgroundColor: colors.card }]}><Text style={[styles.eyebrow, { color: colors.accent }]}>TACTICAL SIMULATION / MOBILE UNIT</Text><Text style={[styles.title, { color: colors.foreground }]}>NEON</Text><Text style={[styles.title, { color: colors.primary }]}>BREACH</Text><Text style={[styles.copy, { color: colors.secondaryForeground }]}>A touch-first survival drill. Move the breach, break the rush, and keep the corridor yours.</Text><View style={styles.meta}><Text style={[styles.metaText, { color: colors.mutedForeground }]}>DRAG TO MOVE</Text><Text style={[styles.metaText, { color: colors.mutedForeground }]}>HOLD FIRE</Text><Text style={[styles.metaText, { color: colors.mutedForeground }]}>TAP RELOAD</Text></View><Pressable testID="mobile-play" onPress={startRun} style={({ pressed }) => [styles.primaryButton, { backgroundColor: colors.primary, opacity: pressed ? .72 : 1 }]}><Text style={[styles.primaryButtonText, { color: colors.primaryForeground }]}>ENTER THE BREACH</Text><Ionicons name="arrow-forward" size={18} color={colors.primaryForeground} /></Pressable></View>}
        {phase === 'over' && <View style={[styles.card, { borderColor: colors.destructive, backgroundColor: colors.card }]}><Text style={[styles.eyebrow, { color: colors.destructive }]}>SIGNAL LOST / RUN TERMINATED</Text><Text style={[styles.title, { color: colors.destructive }]}>BREACH</Text><Text style={[styles.title, { color: colors.destructive }]}>FAILED</Text><Text style={[styles.finalLabel, { color: colors.mutedForeground }]}>FINAL SCORE</Text><Text testID="mobile-final-score" style={[styles.finalScore, { color: colors.foreground }]}>{score.toLocaleString()}</Text><Pressable testID="mobile-restart" onPress={startRun} style={({ pressed }) => [styles.primaryButton, { backgroundColor: colors.primary, opacity: pressed ? .72 : 1 }]}><Text style={[styles.primaryButtonText, { color: colors.primaryForeground }]}>RUN IT BACK</Text></Pressable></View>}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  arena: { flex: 1, position: 'relative', overflow: 'hidden' },
  grid: { ...StyleSheet.absoluteFillObject, opacity: .18, borderWidth: 1, borderColor: '#1f6c6d', margin: 16 },
  card: { marginHorizontal: 22, padding: 26, borderWidth: 1, borderRadius: 8, shadowColor: '#000', shadowOpacity: .45, shadowRadius: 26, shadowOffset: { width: 0, height: 12 }, elevation: 9 },
  eyebrow: { fontFamily: 'Inter_600SemiBold', fontSize: 10, letterSpacing: 1.8, marginBottom: 20 },
  title: { fontFamily: 'Inter_700Bold', fontSize: 58, lineHeight: 54, letterSpacing: -2 },
  copy: { fontFamily: 'Inter_400Regular', fontSize: 14, lineHeight: 22, marginTop: 22, marginBottom: 26 },
  meta: { flexDirection: 'row', gap: 8, flexWrap: 'wrap', marginBottom: 26 },
  metaText: { fontFamily: 'Inter_600SemiBold', fontSize: 9, letterSpacing: 1, borderWidth: 1, borderColor: '#285c61', paddingHorizontal: 9, paddingVertical: 7 },
  primaryButton: { minHeight: 54, paddingHorizontal: 18, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 12, borderRadius: 4 },
  primaryButtonText: { fontFamily: 'Inter_700Bold', fontSize: 13, letterSpacing: 1.2 },
  topHud: { position: 'absolute', left: 22, right: 22, top: 18, flexDirection: 'row', justifyContent: 'space-between' },
  centerHud: { alignItems: 'center' },
  rightHud: { alignItems: 'flex-end' },
  label: { fontFamily: 'Inter_600SemiBold', fontSize: 9, letterSpacing: 1.3 },
  hudValue: { fontFamily: 'Inter_700Bold', fontSize: 28, marginTop: 3 },
  smallValue: { fontFamily: 'Inter_400Regular', fontSize: 13, color: '#83a7a6' },
  minimap: { position: 'absolute', right: 22, top: 84, width: 102, height: 102, borderWidth: 1, borderColor: '#285c61', backgroundColor: '#091e23' },
  minimapPlayer: { position: 'absolute', width: 7, height: 7, borderRadius: 4, marginLeft: -3, marginTop: -3 },
  minimapEnemy: { position: 'absolute', width: 5, height: 5, borderRadius: 3, marginLeft: -2, marginTop: -2 },
  enemy: { position: 'absolute', width: 48, height: 48, marginLeft: -24, marginTop: -24, borderWidth: 1, borderRadius: 6, alignItems: 'center', justifyContent: 'center' },
  enemyBar: { position: 'absolute', left: 4, right: 4, bottom: -8, height: 4, backgroundColor: '#071016', borderWidth: 1, borderColor: '#285c61' },
  enemyFill: { height: '100%' },
  player: { position: 'absolute', width: 42, height: 42, marginLeft: -21, marginTop: -21, borderWidth: 2, borderRadius: 22, alignItems: 'center', justifyContent: 'center', backgroundColor: '#0d2028' },
  crosshair: { position: 'absolute', left: '50%', top: '50%', width: 24, height: 24, marginLeft: -12, marginTop: -12, alignItems: 'center', justifyContent: 'center' },
  crosshairLine: { position: 'absolute', width: 22, height: 1 },
  crosshairLineVertical: { position: 'absolute', width: 1, height: 22 },
  bottomHud: { position: 'absolute', left: 22, right: 22, bottom: 134, flexDirection: 'row', alignItems: 'flex-end', justifyContent: 'space-between' },
  healthBlock: { width: '58%' },
  healthRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 6 },
  healthText: { fontFamily: 'Inter_700Bold', fontSize: 20 },
  healthTrack: { height: 8, borderWidth: 1, transform: [{ skewX: '-12deg' }] },
  healthFill: { height: '100%' },
  status: { fontFamily: 'Inter_600SemiBold', fontSize: 9, letterSpacing: .7, marginTop: 8 },
  ammoBlock: { alignItems: 'flex-end' },
  ammo: { fontFamily: 'Inter_700Bold', fontSize: 45, lineHeight: 45 },
  ammoMax: { fontFamily: 'Inter_400Regular', fontSize: 16, color: '#83a7a6' },
  touchRow: { position: 'absolute', left: 22, right: 22, bottom: 24, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  joystick: { width: 86, height: 86, borderRadius: 43, borderWidth: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: '#0b2028aa' },
  joystickKnob: { width: 34, height: 34, borderRadius: 17, opacity: .72 },
  actionCluster: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  iconButton: { width: 48, height: 48, borderRadius: 24, borderWidth: 1, alignItems: 'center', justifyContent: 'center' },
  fireButton: { width: 70, height: 70, borderRadius: 35, alignItems: 'center', justifyContent: 'center' },
  finalLabel: { fontFamily: 'Inter_600SemiBold', fontSize: 10, letterSpacing: 1.7, textAlign: 'center', marginTop: 28 },
  finalScore: { fontFamily: 'Inter_700Bold', fontSize: 58, textAlign: 'center', marginVertical: 10 },
});