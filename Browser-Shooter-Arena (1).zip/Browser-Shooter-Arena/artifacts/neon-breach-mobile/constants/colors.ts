/**
 * Semantic design tokens for the mobile app.
 *
 * These tokens mirror the naming conventions used in web artifacts (index.css)
 * so that multi-artifact projects share a cohesive visual identity.
 *
 * Replace the placeholder values below with values that match the project's
 * brand. If a sibling web artifact exists, read its index.css and convert the
 * HSL values to hex so both artifacts use the same palette.
 *
 * To add dark mode, add a `dark` key with the same token names.
 * The useColors() hook will automatically pick it up.
 */

const colors = {
  light: {
    text: '#e9fbf4',
    tint: '#83efdd',
    background: '#071016',
    foreground: '#e9fbf4',
    card: '#0d2028',
    cardForeground: '#e9fbf4',
    primary: '#83efdd',
    primaryForeground: '#061417',
    secondary: '#123a40',
    secondaryForeground: '#a8cac4',
    muted: '#123a40',
    mutedForeground: '#83a7a6',
    accent: '#ffbf69',
    accentForeground: '#071016',
    destructive: '#ff6b70',
    destructiveForeground: '#ffffff',
    border: '#285c61',
    input: '#285c61',
  },
  dark: {
    text: '#e9fbf4',
    tint: '#83efdd',
    background: '#071016',
    foreground: '#e9fbf4',
    card: '#0d2028',
    cardForeground: '#e9fbf4',
    primary: '#83efdd',
    primaryForeground: '#061417',
    secondary: '#123a40',
    secondaryForeground: '#a8cac4',
    muted: '#123a40',
    mutedForeground: '#83a7a6',
    accent: '#ffbf69',
    accentForeground: '#071016',
    destructive: '#ff6b70',
    destructiveForeground: '#ffffff',
    border: '#285c61',
    input: '#285c61',
  },

  // Border radius (in px). Sync from the sibling web artifact's --radius
  // CSS variable. This value applies to cards, buttons, inputs, and modals.
  radius: 8,
};

export default colors;
