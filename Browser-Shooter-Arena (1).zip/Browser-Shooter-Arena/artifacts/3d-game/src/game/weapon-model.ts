import type { WeaponDefinition, WeaponId } from './weapon-config';

export interface WeaponView {
  group: any;
  flash: any;
  flashLight: any;
  dispose: () => void;
}

interface WeaponProfile {
  width: number;
  height: number;
  bodyLength: number;
  barrelLength: number;
  barrelRadius: number;
  magazineWidth: number;
  magazineDepth: number;
  stock: boolean;
  scope: boolean;
  barrelCount: number;
}

const PROFILES: Record<WeaponId, WeaponProfile> = {
  pistol: { width: 0.25, height: 0.23, bodyLength: 0.55, barrelLength: 0.55, barrelRadius: 0.065, magazineWidth: 0.14, magazineDepth: 0.16, stock: false, scope: false, barrelCount: 1 },
  smg: { width: 0.25, height: 0.25, bodyLength: 0.68, barrelLength: 0.62, barrelRadius: 0.055, magazineWidth: 0.15, magazineDepth: 0.18, stock: true, scope: false, barrelCount: 1 },
  'assault-rifle': { width: 0.28, height: 0.27, bodyLength: 0.78, barrelLength: 0.78, barrelRadius: 0.06, magazineWidth: 0.16, magazineDepth: 0.19, stock: true, scope: false, barrelCount: 1 },
  shotgun: { width: 0.31, height: 0.29, bodyLength: 0.72, barrelLength: 0.75, barrelRadius: 0.085, magazineWidth: 0.12, magazineDepth: 0.15, stock: true, scope: false, barrelCount: 1 },
  sniper: { width: 0.22, height: 0.23, bodyLength: 0.92, barrelLength: 1.18, barrelRadius: 0.045, magazineWidth: 0.12, magazineDepth: 0.15, stock: true, scope: true, barrelCount: 1 },
  lmg: { width: 0.35, height: 0.32, bodyLength: 0.82, barrelLength: 0.88, barrelRadius: 0.075, magazineWidth: 0.22, magazineDepth: 0.23, stock: true, scope: false, barrelCount: 1 },
  minigun: { width: 0.38, height: 0.34, bodyLength: 0.72, barrelLength: 0.86, barrelRadius: 0.04, magazineWidth: 0.25, magazineDepth: 0.23, stock: false, scope: false, barrelCount: 4 },
};

export function buildWeaponModel(THREE: any, definition: WeaponDefinition): WeaponView {
  const profile = PROFILES[definition.id];
  const group = new THREE.Group();
  const dark = new THREE.MeshStandardMaterial({ color: 0x17252b, emissive: 0x071215, emissiveIntensity: 0.2, roughness: 0.7, metalness: 0.34 });
  const accent = new THREE.MeshStandardMaterial({ color: definition.tracerColor, emissive: definition.tracerColor, emissiveIntensity: 0.48, roughness: 0.48, metalness: 0.28 });
  const barrelEnd = -(profile.bodyLength * 0.56 + profile.barrelLength);
  const body = new THREE.Mesh(new THREE.BoxGeometry(profile.width, profile.height, profile.bodyLength), dark);
  body.position.set(0, 0.02, -profile.bodyLength * 0.2);
  body.rotation.x = -0.08;
  group.add(body);

  const receiver = new THREE.Mesh(new THREE.BoxGeometry(profile.width * 1.18, profile.height * 0.68, profile.bodyLength * 0.48), accent);
  receiver.position.set(0, profile.height * 0.48, -profile.bodyLength * 0.32);
  group.add(receiver);

  for (let index = 0; index < profile.barrelCount; index += 1) {
    const barrel = new THREE.Mesh(
      new THREE.CylinderGeometry(profile.barrelRadius, profile.barrelRadius * 1.08, profile.barrelLength, 10),
      dark,
    );
    barrel.rotation.x = Math.PI / 2;
    const offset = profile.barrelCount === 1 ? 0 : (index - (profile.barrelCount - 1) / 2) * profile.barrelRadius * 2.25;
    barrel.position.set(offset, 0.06, -(profile.bodyLength * 0.56 + profile.barrelLength * 0.5));
    group.add(barrel);
  }

  if (profile.barrelCount === 1) {
    const barrelGlow = new THREE.Mesh(
      new THREE.CylinderGeometry(profile.barrelRadius * 0.42, profile.barrelRadius * 0.42, profile.barrelLength * 0.96, 8),
      accent,
    );
    barrelGlow.rotation.x = Math.PI / 2;
    barrelGlow.position.set(0, 0.06, -(profile.bodyLength * 0.56 + profile.barrelLength * 0.5));
    group.add(barrelGlow);
  }

  const grip = new THREE.Mesh(new THREE.BoxGeometry(profile.width * 0.62, 0.36, 0.17), dark);
  grip.position.set(0, -0.19, profile.bodyLength * 0.08);
  grip.rotation.x = -0.22;
  group.add(grip);

  const magazine = new THREE.Mesh(
    new THREE.BoxGeometry(profile.magazineWidth, definition.magazineSize > 40 ? 0.4 : 0.28, profile.magazineDepth),
    definition.id === 'pistol' ? dark : accent,
  );
  magazine.position.set(0, -0.2, -profile.bodyLength * 0.24);
  group.add(magazine);

  if (profile.stock) {
    const stock = new THREE.Mesh(new THREE.BoxGeometry(profile.width * 0.72, profile.height * 0.62, 0.4), dark);
    stock.position.set(0, -0.015, profile.bodyLength * 0.33);
    group.add(stock);
  }
  if (definition.id === 'smg' || definition.id === 'shotgun' || definition.id === 'lmg' || definition.id === 'minigun') {
    const foregrip = new THREE.Mesh(new THREE.BoxGeometry(profile.width * 0.58, 0.27, 0.15), dark);
    foregrip.position.set(0, -0.2, -profile.bodyLength * 0.38);
    group.add(foregrip);
  }
  if (profile.scope) {
    const scope = new THREE.Mesh(new THREE.CylinderGeometry(0.065, 0.065, 0.38, 10), dark);
    scope.rotation.x = Math.PI / 2;
    scope.position.set(0, profile.height * 0.72, -profile.bodyLength * 0.28);
    group.add(scope);
    const lens = new THREE.Mesh(new THREE.CylinderGeometry(0.046, 0.046, 0.02, 10), accent);
    lens.rotation.x = Math.PI / 2;
    lens.position.set(0, profile.height * 0.72, -profile.bodyLength * 0.28 - 0.2);
    group.add(lens);
  }

  group.position.set(0.39, -0.31, -0.62);
  group.rotation.set(-0.08, -0.08, -0.06);
  const flash = new THREE.Mesh(
    new THREE.SphereGeometry(definition.id === 'shotgun' || definition.id === 'sniper' ? 0.16 : 0.12, 8, 8),
    new THREE.MeshStandardMaterial({ color: definition.tracerColor, emissive: definition.tracerColor, emissiveIntensity: 5 }),
  );
  flash.position.set(0, 0.06, barrelEnd - 0.04);
  flash.visible = false;
  group.add(flash);
  const flashLight = new THREE.PointLight(definition.tracerColor, 0, 4, 2);
  flashLight.position.copy(flash.position);
  group.add(flashLight);

  return {
    group,
    flash,
    flashLight,
    dispose() {
      group.traverse((object: any) => {
        if (!object.isMesh) return;
        object.geometry?.dispose();
        if (Array.isArray(object.material)) object.material.forEach((material: any) => material.dispose());
        else object.material?.dispose();
      });
    },
  };
}