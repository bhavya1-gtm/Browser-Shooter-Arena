export type EnemyKind = 'walker' | 'runner' | 'tank';

export interface EnemyDefinition {
  label: string;
  unlockWave: number;
  spawnWeight: number;
  health: number;
  healthPerWave: number;
  speed: number;
  speedPerWave: number;
  attackRange: number;
  attackCooldown: number;
  damage: number;
  score: number;
  hitRadius: number;
  aimHeight: number;
  minimapColor: string;
}

export interface WaveDifficulty {
  level: number;
  pressure: number;
  enemyCount: number;
  detectionRange: number;
}

export const ENEMY_DEFINITIONS: Record<EnemyKind, EnemyDefinition> = {
  walker: {
    label: 'WALKER',
    unlockWave: 1,
    spawnWeight: 0.62,
    health: 48,
    healthPerWave: 7,
    speed: 1.55,
    speedPerWave: 0.1,
    attackRange: 1.55,
    attackCooldown: 1.05,
    damage: 6,
    score: 90,
    hitRadius: 0.68,
    aimHeight: 0.82,
    minimapColor: '#83efdd',
  },
  runner: {
    label: 'RUNNER',
    unlockWave: 5,
    spawnWeight: 0.32,
    health: 58,
    healthPerWave: 9,
    speed: 2.55,
    speedPerWave: 0.14,
    attackRange: 1.5,
    attackCooldown: 0.82,
    damage: 8,
    score: 125,
    hitRadius: 0.82,
    aimHeight: 0.78,
    minimapColor: '#ff6b70',
  },
  tank: {
    label: 'TANK',
    unlockWave: 10,
    spawnWeight: 0.13,
    health: 118,
    healthPerWave: 24,
    speed: 1.1,
    speedPerWave: 0.12,
    attackRange: 2.2,
    attackCooldown: 1.35,
    damage: 14,
    score: 260,
    hitRadius: 1.08,
    aimHeight: 0.95,
    minimapColor: '#ffbf69',
  },
};

export function waveDifficulty(wave: number): WaveDifficulty {
  const level = Math.max(1, Math.floor(wave));
  const pressure = level - 1;
  return {
    level,
    pressure,
    enemyCount: Math.min(24, 5 + level * 2),
    detectionRange: Math.min(24, 10.5 + pressure * 0.35),
  };
}

export function enemyStats(kind: EnemyKind, wave: number) {
  const definition = ENEMY_DEFINITIONS[kind];
  const { pressure } = waveDifficulty(wave);
  return {
    health: Math.ceil((definition.health + pressure * definition.healthPerWave) * (1 + pressure * 0.018)),
    speed: (definition.speed + definition.speedPerWave * Math.sqrt(pressure)) * (1 + Math.min(0.35, pressure * 0.004)),
    damage: Math.ceil(definition.damage + pressure * 1.15),
    attackCooldown: Math.max(0.38, definition.attackCooldown / (1 + pressure * 0.04)),
    score: definition.score,
  };
}

export function chooseEnemyKind(wave: number, roll: number): EnemyKind {
  const available = (Object.entries(ENEMY_DEFINITIONS) as [EnemyKind, EnemyDefinition][])
    .filter(([, definition]) => definition.unlockWave <= wave);
  const totalWeight = available.reduce((total, [, definition]) => total + definition.spawnWeight, 0);
  let remaining = roll * totalWeight;
  for (const [kind, definition] of available) {
    remaining -= definition.spawnWeight;
    if (remaining <= 0) return kind;
  }
  return available[available.length - 1][0];
}