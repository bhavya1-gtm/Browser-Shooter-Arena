export const WEAPON_IDS = ['pistol', 'smg', 'assault-rifle', 'shotgun', 'sniper', 'lmg', 'minigun'] as const;
export type WeaponId = typeof WEAPON_IDS[number];

export interface WeaponDefinition {
  id: WeaponId;
  label: string;
  shortLabel: string;
  key: string;
  slot: 'SIDEARM' | 'PRIMARY';
  magazineSize: number;
  reserveCapacity: number;
  startingReserve: number;
  damage: number;
  fireInterval: number;
  reloadDuration: number;
  spread: number;
  range: number;
  pellets: number;
  recoil: number;
  headshotMultiplier: number;
  tracerColor: number;
}

export const WEAPON_DEFINITIONS: Record<WeaponId, WeaponDefinition> = {
  pistol: {
    id: 'pistol', label: 'Pistol', shortLabel: 'PSTL', key: '1', slot: 'SIDEARM',
    magazineSize: 12, reserveCapacity: 96, startingReserve: 60,
    damage: 46, fireInterval: 0.22, reloadDuration: 1.15,
    spread: 0.0025, range: 80, pellets: 1, recoil: 0.16, headshotMultiplier: 1.8, tracerColor: 0xffd176,
  },
  smg: {
    id: 'smg', label: 'SMG', shortLabel: 'SMG', key: '2', slot: 'PRIMARY',
    magazineSize: 30, reserveCapacity: 240, startingReserve: 150,
    damage: 19, fireInterval: 0.075, reloadDuration: 1.55,
    spread: 0.013, range: 56, pellets: 1, recoil: 0.055, headshotMultiplier: 1.55, tracerColor: 0x83efdd,
  },
  'assault-rifle': {
    id: 'assault-rifle', label: 'Assault Rifle', shortLabel: 'AR', key: '3', slot: 'PRIMARY',
    magazineSize: 30, reserveCapacity: 240, startingReserve: 150,
    damage: 30, fireInterval: 0.12, reloadDuration: 1.7,
    spread: 0.006, range: 82, pellets: 1, recoil: 0.09, headshotMultiplier: 1.75, tracerColor: 0xffbf69,
  },
  shotgun: {
    id: 'shotgun', label: 'Shotgun', shortLabel: 'SHOT', key: '4', slot: 'PRIMARY',
    magazineSize: 8, reserveCapacity: 80, startingReserve: 40,
    damage: 13, fireInterval: 0.72, reloadDuration: 1.95,
    spread: 0.047, range: 34, pellets: 8, recoil: 0.28, headshotMultiplier: 1.45, tracerColor: 0xffa36b,
  },
  sniper: {
    id: 'sniper', label: 'Sniper', shortLabel: 'SNIPE', key: '5', slot: 'PRIMARY',
    magazineSize: 5, reserveCapacity: 50, startingReserve: 25,
    damage: 108, fireInterval: 0.92, reloadDuration: 2.05,
    spread: 0.0004, range: 140, pellets: 1, recoil: 0.34, headshotMultiplier: 2.35, tracerColor: 0x9ceeff,
  },
  lmg: {
    id: 'lmg', label: 'LMG', shortLabel: 'LMG', key: '6', slot: 'PRIMARY',
    magazineSize: 100, reserveCapacity: 500, startingReserve: 250,
    damage: 15, fireInterval: 0.085, reloadDuration: 3.0,
    spread: 0.018, range: 74, pellets: 1, recoil: 0.07, headshotMultiplier: 1.6, tracerColor: 0xffbf69,
  },
  minigun: {
    id: 'minigun', label: 'Minigun', shortLabel: 'MINI', key: '7', slot: 'PRIMARY',
    magazineSize: 200, reserveCapacity: 800, startingReserve: 400,
    damage: 11, fireInterval: 0.055, reloadDuration: 4.2,
    spread: 0.026, range: 66, pellets: 1, recoil: 0.065, headshotMultiplier: 1.5, tracerColor: 0x83efdd,
  },
};

export function createStartingMagazines(): Record<WeaponId, number> {
  return Object.fromEntries(WEAPON_IDS.map((id) => [id, WEAPON_DEFINITIONS[id].magazineSize])) as Record<WeaponId, number>;
}

export function createStartingReserves(): Record<WeaponId, number> {
  return Object.fromEntries(WEAPON_IDS.map((id) => [id, WEAPON_DEFINITIONS[id].startingReserve])) as Record<WeaponId, number>;
}