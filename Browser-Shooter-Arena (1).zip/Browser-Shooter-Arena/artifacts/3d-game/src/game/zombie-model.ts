import type { EnemyKind } from './enemy-config';

export interface ZombieRig {
  group: any;
  body: any;
  head: any;
  leftArm: any;
  rightArm: any;
  leftLeg: any;
  rightLeg: any;
}

export function createZombieFactory(THREE: any) {
  const materials = {
    skinWalker: new THREE.MeshStandardMaterial({ color: 0x82947a, roughness: 0.96 }),
    skinRunner: new THREE.MeshStandardMaterial({ color: 0x748c70, roughness: 0.92 }),
    skinTank: new THREE.MeshStandardMaterial({ color: 0x64756b, roughness: 0.98 }),
    clothWalker: new THREE.MeshStandardMaterial({ color: 0x33473d, roughness: 0.96 }),
    clothRunner: new THREE.MeshStandardMaterial({ color: 0x68433a, roughness: 0.94 }),
    clothTank: new THREE.MeshStandardMaterial({ color: 0x4d3037, roughness: 0.97 }),
    underCloth: new THREE.MeshStandardMaterial({ color: 0x202a28, roughness: 1 }),
    armor: new THREE.MeshStandardMaterial({ color: 0x38494a, roughness: 0.8, metalness: 0.18 }),
    wound: new THREE.MeshStandardMaterial({ color: 0x542c2e, roughness: 1 }),
    eye: new THREE.MeshStandardMaterial({ color: 0xffa05e, emissive: 0xff542e, emissiveIntensity: 1.65 }),
    tooth: new THREE.MeshStandardMaterial({ color: 0xd6d0ad, roughness: 0.8 }),
  };
  const geometry = {
    walkerTorso: new THREE.CapsuleGeometry(0.34, 0.46, 4, 8),
    runnerTorso: new THREE.CapsuleGeometry(0.3, 0.5, 4, 8),
    tankTorso: new THREE.CapsuleGeometry(0.46, 0.68, 4, 8),
    head: new THREE.SphereGeometry(0.26, 12, 10),
    neck: new THREE.CylinderGeometry(0.13, 0.16, 0.23, 8),
    upperArm: new THREE.CapsuleGeometry(0.13, 0.34, 3, 7),
    forearm: new THREE.CapsuleGeometry(0.105, 0.32, 3, 7),
    hand: new THREE.SphereGeometry(0.12, 8, 7),
    finger: new THREE.ConeGeometry(0.035, 0.16, 5),
    upperLeg: new THREE.CapsuleGeometry(0.15, 0.36, 3, 7),
    lowerLeg: new THREE.CapsuleGeometry(0.12, 0.34, 3, 7),
    boot: new THREE.BoxGeometry(0.28, 0.18, 0.4),
    eye: new THREE.SphereGeometry(0.045, 8, 6),
    mouth: new THREE.BoxGeometry(0.2, 0.065, 0.035),
    tooth: new THREE.BoxGeometry(0.035, 0.045, 0.025),
    patch: new THREE.BoxGeometry(1, 1, 1),
    shoulder: new THREE.BoxGeometry(1, 1, 1),
    strap: new THREE.BoxGeometry(1, 1, 1),
    hair: new THREE.SphereGeometry(0.14, 8, 6),
  };

  function makeMesh(geo: any, material: any, parent: any, position: [number, number, number], scale?: [number, number, number]) {
    const mesh = new THREE.Mesh(geo, material);
    mesh.position.set(...position);
    if (scale) mesh.scale.set(...scale);
    mesh.castShadow = true;
    mesh.receiveShadow = true;
    parent.add(mesh);
    return mesh;
  }

  function build(kind: EnemyKind): ZombieRig {
    const isTank = kind === 'tank';
    const isRunner = kind === 'runner';
    const group = new THREE.Group();
    const skin = isTank ? materials.skinTank : isRunner ? materials.skinRunner : materials.skinWalker;
    const cloth = isTank ? materials.clothTank : isRunner ? materials.clothRunner : materials.clothWalker;
    const torsoY = isTank ? 1.18 : 0.99;
    const shoulderWidth = isTank ? 0.52 : isRunner ? 0.34 : 0.39;

    const body = makeMesh(
      isTank ? geometry.tankTorso : isRunner ? geometry.runnerTorso : geometry.walkerTorso,
      cloth,
      group,
      [0, torsoY, 0],
      isTank ? [1.12, 1.05, 0.92] : [1, 1, 0.9],
    );
    body.rotation.x = isRunner ? -0.24 : -0.08;

    const neckY = isTank ? 1.65 : 1.43;
    makeMesh(geometry.neck, skin, group, [0, neckY, -0.015]);
    const head = makeMesh(geometry.head, skin, group, [isRunner ? 0.045 : 0, isTank ? 2.0 : 1.67, -0.03], isTank ? [1.12, 1.05, 0.96] : [1, 1, 0.92]);
    head.rotation.z = isRunner ? -0.12 : 0.04;

    const faceY = isTank ? 2.0 : 1.67;
    const faceZ = -0.255;
    makeMesh(geometry.mouth, materials.wound, group, [0, faceY - 0.12, faceZ]);
    makeMesh(geometry.tooth, materials.tooth, group, [-0.055, faceY - 0.095, faceZ - 0.022]);
    makeMesh(geometry.tooth, materials.tooth, group, [0.035, faceY - 0.095, faceZ - 0.022]);
    makeMesh(geometry.eye, materials.eye, group, [-0.105, faceY + 0.015, faceZ - 0.012]);
    makeMesh(geometry.eye, materials.eye, group, [0.105, faceY + 0.015, faceZ - 0.012]);
    makeMesh(geometry.hair, materials.underCloth, group, [0.02, faceY + 0.205, 0.005], [1.55, 0.55, 1.25]);

    if (isTank) {
      makeMesh(geometry.shoulder, materials.armor, group, [-0.49, 1.56, 0], [0.5, 0.22, 0.62]);
      makeMesh(geometry.shoulder, materials.armor, group, [0.49, 1.56, 0], [0.5, 0.22, 0.62]);
      makeMesh(geometry.strap, materials.armor, group, [0.08, 1.2, -0.38], [0.14, 0.83, 0.07]).rotation.z = -0.48;
      makeMesh(geometry.patch, materials.wound, group, [-0.2, 1.12, -0.41], [0.22, 0.14, 0.025]);
    } else {
      makeMesh(geometry.patch, materials.underCloth, group, [-0.16, 1.07, -0.305], [0.24, 0.31, 0.04]);
      makeMesh(geometry.patch, materials.wound, group, [0.19, 1.23, -0.29], [0.2, 0.12, 0.035]).rotation.z = -0.4;
      if (isRunner) {
        makeMesh(geometry.patch, materials.skinRunner, group, [0.43, 1.3, -0.04], [0.12, 0.28, 0.13]);
      }
    }

    const createArm = (side: number) => {
      const pivot = new THREE.Group();
      pivot.position.set(side * shoulderWidth, isTank ? 1.49 : 1.28, 0);
      group.add(pivot);
      const armSkin = makeMesh(geometry.upperArm, skin, pivot, [0, -0.25, 0]);
      makeMesh(geometry.forearm, isTank ? skin : cloth, pivot, [side * 0.025, -0.63, -0.015]);
      makeMesh(geometry.hand, skin, pivot, [side * 0.04, -0.86, -0.08]);
      for (let finger = -1; finger <= 1; finger += 1) {
        makeMesh(geometry.finger, skin, pivot, [side * 0.04 + finger * 0.065, -0.98, -0.14], [0.7, 1, 0.7]).rotation.x = -0.48;
      }
      if (!isTank) {
        const sleeve = makeMesh(geometry.upperArm, cloth, pivot, [0, -0.19, 0], [1.13, 0.72, 1.13]);
        sleeve.material = cloth;
      }
      armSkin.rotation.z = side * -0.08;
      return pivot;
    };

    const createLeg = (side: number) => {
      const pivot = new THREE.Group();
      pivot.position.set(side * (isTank ? 0.25 : 0.19), isTank ? 0.83 : 0.69, 0);
      group.add(pivot);
      makeMesh(geometry.upperLeg, cloth, pivot, [0, -0.21, 0]);
      makeMesh(geometry.lowerLeg, skin, pivot, [0, -0.57, -0.015]);
      makeMesh(geometry.boot, materials.underCloth, pivot, [0, -0.81, -0.075]);
      return pivot;
    };

    const leftArm = createArm(-1);
    const rightArm = createArm(1);
    const leftLeg = createLeg(-1);
    const rightLeg = createLeg(1);
    return { group, body, head, leftArm, rightArm, leftLeg, rightLeg };
  }

  return {
    build,
    dispose() {
      Object.values(geometry).forEach((item: any) => item.dispose());
      Object.values(materials).forEach((item: any) => item.dispose());
    },
  };
}