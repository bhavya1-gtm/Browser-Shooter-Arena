import { useCallback, useEffect, useRef, useState, type PointerEvent as ReactPointerEvent } from 'react';
import { chooseEnemyKind, ENEMY_DEFINITIONS, enemyStats, waveDifficulty, type EnemyKind } from './game/enemy-config';
import { createStartingMagazines, createStartingReserves, WEAPON_DEFINITIONS, WEAPON_IDS, type WeaponId } from './game/weapon-config';
import { buildWeaponModel, type WeaponView } from './game/weapon-model';
import { createZombieFactory, type ZombieRig } from './game/zombie-model';

declare global {
  interface Window {
    THREE: any;
  }
}

type GameMode = 'start' | 'playing' | 'over';
type PickupKind = 'health' | 'ammo' | 'speed';

interface EnemyUnit {
  group: any;
  body: any;
  bar: any;
  kind: EnemyKind;
  rig: ZombieRig;
  hp: number;
  maxHp: number;
  state: 'patrol' | 'chase' | 'dying';
  patrol: any;
  attackAt: number;
  deathAt: number;
  seed: number;
}

interface Pickup {
  group: any;
  kind: PickupKind;
  expires: number;
}

interface HudState {
  health: number;
  ammo: number;
  ammoCapacity: number;
  reserveAmmo: number;
  weaponId: WeaponId;
  weaponLabel: string;
  wave: number;
  score: number;
  combo: number;
  enemies: number;
  status: string;
  reload: boolean;
}

interface Runtime {
  THREE: any;
  scene: any;
  camera: any;
  renderer: any;
  weapon: any;
  flash: any;
  flashLight: any;
  weaponModels: Record<WeaponId, WeaponView>;
  selectedWeaponId: WeaponId;
  canvas: HTMLCanvasElement;
  enemies: EnemyUnit[];
  pickups: Pickup[];
  keys: Record<string, boolean>;
  mouseDown: boolean;
  yaw: number;
  pitch: number;
  recoil: number;
  shake: number;
  now: number;
  player: {
    pos: any;
    health: number;
    magazines: Record<WeaponId, number>;
    reserveAmmo: Record<WeaponId, number>;
    speedUntil: number;
    grounded: boolean;
    velocityY: number;
  };
  wave: number;
  score: number;
  combo: number;
  comboUntil: number;
  spawnOrdinal: number;
  waveDelay: number;
  nextShot: number;
  reloadUntil: number;
  reloadWeaponId: WeaponId | null;
  reloadStartedAt: number;
  weaponSwitchAt: number;
  status: string;
  statusUntil: number;
  hitAt: number;
  touchMove: { x: number; y: number };
  ambient?: { osc: any; gain: any };
  audio?: AudioContext;
  resetGame?: () => void;
  startAudio?: () => void;
  switchWeapon?: (weaponId: WeaponId) => void;
  reload?: () => void;
}

const clamp = (value: number, min: number, max: number) => Math.max(min, Math.min(max, value));
const seeded = (seed: number) => {
  const x = Math.sin(seed * 12.9898 + 78.233) * 43758.5453;
  return x - Math.floor(x);
};

function makeMaterial(THREE: any, color: number, emissive = 0x000000, intensity = 0) {
  return new THREE.MeshStandardMaterial({
    color,
    emissive,
    emissiveIntensity: intensity,
    roughness: .72,
    metalness: .28,
  });
}

function makeHealthBar(THREE: any, color: string) {
  const canvas = document.createElement('canvas');
  canvas.width = 128;
  canvas.height = 16;
  const context = canvas.getContext('2d')!;
  context.fillStyle = 'rgba(3,10,12,.88)';
  context.fillRect(0, 0, 128, 16);
  context.fillStyle = color;
  context.fillRect(1, 1, 126, 14);
  const texture = new THREE.CanvasTexture(canvas);
  const sprite = new THREE.Sprite(new THREE.SpriteMaterial({ map: texture, transparent: true, depthTest: false }));
  sprite.scale.set(1.38, .17, 1);
  sprite.userData.canvas = canvas;
  sprite.userData.context = context;
  sprite.userData.texture = texture;
  return sprite;
}

function updateHealthBar(enemy: EnemyUnit) {
  const context = enemy.bar.userData.context as CanvasRenderingContext2D;
  const color = ENEMY_DEFINITIONS[enemy.kind].minimapColor;
  context.clearRect(0, 0, 128, 16);
  context.fillStyle = 'rgba(3,10,12,.9)';
  context.fillRect(0, 0, 128, 16);
  context.fillStyle = color;
  context.fillRect(2, 2, 124 * clamp(enemy.hp / enemy.maxHp, 0, 1), 12);
  enemy.bar.userData.texture.needsUpdate = true;
}

function App() {
  const [isMobile, setIsMobile] = useState(false);
  const [webglUnavailable, setWebglUnavailable] = useState(false);
  const [mode, setMode] = useState<GameMode>('start');
  const [isLocked, setIsLocked] = useState(false);
  const [hud, setHud] = useState<HudState>({
    health: 100, ammo: 12, ammoCapacity: 12, reserveAmmo: 60,
    weaponId: 'pistol', weaponLabel: 'Pistol',
    wave: 1, score: 0, combo: 1, enemies: 0, status: 'SYSTEM READY', reload: false,
  });
  const [hitTick, setHitTick] = useState(0);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const minimapRef = useRef<HTMLCanvasElement>(null);
  const runtimeRef = useRef<Runtime | null>(null);
  const modeRef = useRef<GameMode>('start');
  const lockedRef = useRef(false);
  const moveOriginRef = useRef({ x: 0, y: 0 });
  const aimPointRef = useRef({ x: 0, y: 0 });

  modeRef.current = mode;

  useEffect(() => {
    const check = () => setIsMobile(window.matchMedia('(max-width: 767px)').matches);
    check();
    window.addEventListener('resize', check);
    return () => window.removeEventListener('resize', check);
  }, []);

  useEffect(() => {
    if (!canvasRef.current || !window.THREE) return;
    const THREE = window.THREE;
    const canvas = canvasRef.current;
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x071016);
    scene.fog = new THREE.Fog(0x071016, 18, 44);
    const camera = new THREE.PerspectiveCamera(72, window.innerWidth / window.innerHeight, .05, 100);
    camera.position.set(0, 1.55, 9);
    camera.rotation.order = 'YXZ';
    let renderer: any;
    try {
      renderer = new THREE.WebGLRenderer({ canvas, antialias: true, powerPreference: 'high-performance' });
    } catch {
      setWebglUnavailable(true);
      return;
    }
    setWebglUnavailable(false);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.7));
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    const zombieFactory = createZombieFactory(THREE);

    scene.add(new THREE.HemisphereLight(0x80d6cc, 0x071016, 1.05));
    const key = new THREE.DirectionalLight(0xd9fff0, 2.2);
    key.position.set(-8, 16, 9);
    key.castShadow = true;
    key.shadow.mapSize.set(1024, 1024);
    key.shadow.camera.left = -22; key.shadow.camera.right = 22; key.shadow.camera.top = 22; key.shadow.camera.bottom = -22;
    scene.add(key);
    const cyanLight = new THREE.PointLight(0x27cbbb, 8, 18, 2);
    cyanLight.position.set(-12, 2.4, -8);
    scene.add(cyanLight);
    const amberLight = new THREE.PointLight(0xff8556, 5, 13, 2);
    amberLight.position.set(12, 2, 8);
    scene.add(amberLight);

    const floor = new THREE.Mesh(new THREE.PlaneGeometry(40, 40), makeMaterial(THREE, 0x0d2026, 0x061318, .34));
    floor.rotation.x = -Math.PI / 2;
    floor.receiveShadow = true;
    scene.add(floor);
    const grid = new THREE.GridHelper(40, 40, 0x1f6c6d, 0x123a40);
    grid.position.y = .012;
    (grid.material as any).transparent = true;
    (grid.material as any).opacity = .54;
    scene.add(grid);

    const wallMat = makeMaterial(THREE, 0x162c32, 0x0a2023, .55);
    const trimMat = makeMaterial(THREE, 0x3bd9c7, 0x24bfae, 1.7);
    const addBox = (x: number, y: number, z: number, sx: number, sy: number, sz: number, material: any, cast = true) => {
      const mesh = new THREE.Mesh(new THREE.BoxGeometry(sx, sy, sz), material);
      mesh.position.set(x, y, z);
      mesh.castShadow = cast;
      mesh.receiveShadow = true;
      scene.add(mesh);
      return mesh;
    };
    addBox(0, 2.3, -19.2, 40, 4.6, .7, wallMat);
    addBox(0, 2.3, 19.2, 40, 4.6, .7, wallMat);
    addBox(-19.2, 2.3, 0, .7, 4.6, 40, wallMat);
    addBox(19.2, 2.3, 0, .7, 4.6, 40, wallMat);
    addBox(0, .24, -18.78, 34, .08, .04, trimMat, false);
    addBox(0, .24, 18.78, 34, .08, .04, trimMat, false);
    addBox(-18.78, .24, 0, .04, .08, 34, trimMat, false);
    addBox(18.78, .24, 0, .04, .08, 34, trimMat, false);
    const coverSeed = [4.5, -5.8, 8.2, -10.5, 1.5, -1.8, 12.2, -13.4];
    coverSeed.forEach((value, index) => {
      const x = value;
      const z = index % 2 === 0 ? -5.5 + index * .4 : 7.4 - index * .32;
      const sx = index % 3 === 0 ? 3.2 : 2.3;
      addBox(x, .8, z, sx, 1.6, 1.25, wallMat);
      addBox(x, 1.63, z, sx + .12, .06, 1.32, index % 2 ? trimMat : makeMaterial(THREE, 0xffb85e, 0xff7d35, 1.2), false);
    });
    addBox(0, 1.1, 0, 2.3, 2.2, 1.4, wallMat);
    addBox(0, 2.25, 0, 2.45, .07, 1.52, trimMat, false);

    const weaponModels = Object.fromEntries(WEAPON_IDS.map((id) => {
      const view = buildWeaponModel(THREE, WEAPON_DEFINITIONS[id]);
      view.group.visible = id === 'pistol';
      camera.add(view.group);
      return [id, view];
    })) as Record<WeaponId, WeaponView>;
    const weapon = weaponModels.pistol.group;
    const flash = weaponModels.pistol.flash;
    const flashLight = weaponModels.pistol.flashLight;
    scene.add(camera);

    const runtime: Runtime = {
      THREE, scene, camera, renderer, weapon, flash, flashLight, weaponModels, selectedWeaponId: 'pistol', canvas,
      enemies: [], pickups: [], keys: {}, mouseDown: false, yaw: 0, pitch: 0, recoil: 0, shake: 0, now: 0,
      player: {
        pos: new THREE.Vector3(0, 0, 9), health: 100,
        magazines: createStartingMagazines(), reserveAmmo: createStartingReserves(),
        speedUntil: 0, grounded: true, velocityY: 0,
      },
      wave: 1, score: 0, combo: 1, comboUntil: 0, spawnOrdinal: 0, waveDelay: 0, nextShot: 0,
      reloadUntil: 0, reloadWeaponId: null, reloadStartedAt: 0, weaponSwitchAt: 0,
      status: 'SYSTEM READY', statusUntil: 0, hitAt: 0, touchMove: { x: 0, y: 0 },
    };
    runtimeRef.current = runtime;

    const setStatus = (message: string, seconds = 1.4) => {
      runtime.status = message;
      runtime.statusUntil = runtime.now + seconds;
    };
    const switchWeapon = (weaponId: WeaponId) => {
      if (weaponId === runtime.selectedWeaponId) return;
      runtime.weaponModels[runtime.selectedWeaponId].group.visible = false;
      runtime.selectedWeaponId = weaponId;
      const view = runtime.weaponModels[weaponId];
      view.group.visible = true;
      runtime.weapon = view.group;
      runtime.flash = view.flash;
      runtime.flashLight = view.flashLight;
      runtime.weaponSwitchAt = runtime.now;
      runtime.recoil = 0;
      runtime.nextShot = Math.max(runtime.nextShot, runtime.now + 0.1);
      setStatus(`${WEAPON_DEFINITIONS[weaponId].label.toUpperCase()} // READY`, 0.9);
    };
    runtime.switchWeapon = switchWeapon;
    const tone = (frequency: number, duration: number, type: OscillatorType, volume: number) => {
      if (!runtime.audio) return;
      const oscillator = runtime.audio.createOscillator();
      const gain = runtime.audio.createGain();
      oscillator.type = type;
      oscillator.frequency.setValueAtTime(frequency, runtime.audio.currentTime);
      gain.gain.setValueAtTime(volume, runtime.audio.currentTime);
      gain.gain.exponentialRampToValueAtTime(.001, runtime.audio.currentTime + duration);
      oscillator.connect(gain).connect(runtime.audio.destination);
      oscillator.start();
      oscillator.stop(runtime.audio.currentTime + duration);
    };
    const noise = (duration: number, volume: number) => {
      if (!runtime.audio) return;
      const buffer = runtime.audio.createBuffer(1, runtime.audio.sampleRate * duration, runtime.audio.sampleRate);
      const data = buffer.getChannelData(0);
      for (let i = 0; i < data.length; i += 1) data[i] = (seeded(i + runtime.spawnOrdinal * 11) * 2 - 1) * (1 - i / data.length);
      const source = runtime.audio.createBufferSource();
      const gain = runtime.audio.createGain();
      source.buffer = buffer;
      gain.gain.value = volume;
      source.connect(gain).connect(runtime.audio.destination);
      source.start();
    };
    const startAudio = () => {
      if (!runtime.audio) runtime.audio = new AudioContext();
      if (runtime.audio.state === 'suspended') void runtime.audio.resume();
      if (!runtime.ambient) {
        const osc = runtime.audio.createOscillator();
        const gain = runtime.audio.createGain();
        osc.type = 'sine';
        osc.frequency.value = 43;
        gain.gain.value = .018;
        osc.connect(gain).connect(runtime.audio.destination);
        osc.start();
        runtime.ambient = { osc, gain };
      }
    };
    const removeEnemy = (enemy: EnemyUnit) => {
      scene.remove(enemy.group);
      enemy.bar.userData.texture.dispose();
    };
    const clearBattlefield = () => {
      runtime.enemies.forEach(removeEnemy);
      runtime.pickups.forEach((pickup) => scene.remove(pickup.group));
      runtime.enemies = [];
      runtime.pickups = [];
    };
    const spawnEnemy = (kind: EnemyKind) => {
      const index = runtime.spawnOrdinal++;
      const angle = seeded(index * 31 + runtime.wave * 13) * Math.PI * 2;
      const radius = 13.3 + seeded(index * 7 + 9) * 3.4;
      const x = Math.cos(angle) * radius;
      const z = Math.sin(angle) * radius;
      const rig = zombieFactory.build(kind);
      const definition = ENEMY_DEFINITIONS[kind];
      const { health: maxHp } = enemyStats(kind, runtime.wave);
      const group = rig.group;
      const body = rig.body;
      const bar = makeHealthBar(THREE, definition.minimapColor);
      bar.position.y = kind === 'tank' ? 2.36 : 2.02;
      group.add(bar);
      group.position.set(x, 0, z);
      group.userData.enemy = true;
      scene.add(group);
      const enemy: EnemyUnit = { group, body, bar, kind, rig, hp: maxHp, maxHp, state: 'patrol', patrol: new THREE.Vector3(x * .45, 0, z * .45), attackAt: 0, deathAt: 0, seed: index + runtime.wave };
      runtime.enemies.push(enemy);
    };
    const spawnWave = () => {
      const difficulty = waveDifficulty(runtime.wave);
      const count = difficulty.enemyCount;
      for (let index = 0; index < count; index += 1) {
        spawnEnemy(chooseEnemyKind(runtime.wave, seeded(index * 17 + runtime.wave * 29)));
      }
      runtime.waveDelay = 0;
      setStatus(`WAVE ${String(runtime.wave).padStart(2, '0')} // THREAT LEVEL ${difficulty.level} // ${count} CONTACTS INBOUND`, 2.6);
      tone(140 + runtime.wave * 15, .28, 'sawtooth', .04 + runtime.wave * .006);
      if (runtime.ambient) runtime.ambient.gain.gain.value = .018 + runtime.wave * .004;
    };
    const createPickup = (position: any, kind: PickupKind) => {
      const group = new THREE.Group();
      const palette = kind === 'health' ? 0xff6b70 : kind === 'ammo' ? 0xffbf69 : 0xa88dff;
      const material = makeMaterial(THREE, palette, palette, 1.5);
      const cube = new THREE.Mesh(new THREE.BoxGeometry(.38, .38, .38), material);
      cube.rotation.set(.2, .2, .2);
      group.add(cube);
      const ring = new THREE.Mesh(new THREE.TorusGeometry(.36, .025, 6, 18), material);
      ring.rotation.x = Math.PI / 2;
      group.add(ring);
      group.position.copy(position);
      group.position.y = .55;
      scene.add(group);
      runtime.pickups.push({ group, kind, expires: runtime.now + 14 });
    };
    const finishGame = () => {
      if (modeRef.current === 'over') return;
      modeRef.current = 'over';
      setMode('over');
      runtime.status = 'BREACH FAILED';
      runtime.mouseDown = false;
      if (document.pointerLockElement === canvas) document.exitPointerLock();
      tone(75, .6, 'sawtooth', .14);
      noise(.35, .08);
    };
    const resetGame = () => {
      clearBattlefield();
      runtime.player.pos.set(0, 0, 9);
      runtime.player.health = 100;
      runtime.player.magazines = createStartingMagazines();
      runtime.player.reserveAmmo = createStartingReserves();
      runtime.selectedWeaponId = 'pistol';
      WEAPON_IDS.forEach((id) => { runtime.weaponModels[id].group.visible = id === 'pistol'; });
      runtime.weapon = runtime.weaponModels.pistol.group;
      runtime.flash = runtime.weaponModels.pistol.flash;
      runtime.flashLight = runtime.weaponModels.pistol.flashLight;
      runtime.player.speedUntil = 0;
      runtime.player.grounded = true;
      runtime.player.velocityY = 0;
      runtime.wave = 1; runtime.score = 0; runtime.combo = 1; runtime.comboUntil = 0;
      runtime.spawnOrdinal = 0; runtime.nextShot = 0; runtime.reloadUntil = 0; runtime.reloadWeaponId = null; runtime.reloadStartedAt = 0; runtime.waveDelay = 0;
      runtime.yaw = 0; runtime.pitch = 0; runtime.recoil = 0; runtime.shake = 0;
      runtime.touchMove.x = 0; runtime.touchMove.y = 0;
      runtime.camera.position.set(0, 1.55, 9);
      runtime.camera.rotation.set(0, 0, 0);
      spawnWave();
    };
    runtime.resetGame = resetGame;
    const reload = () => {
      if (runtime.reloadUntil > runtime.now) return;
      const weaponId = runtime.selectedWeaponId;
      const definition = WEAPON_DEFINITIONS[weaponId];
      if (runtime.player.magazines[weaponId] >= definition.magazineSize) return;
      if (runtime.player.reserveAmmo[weaponId] <= 0) {
        setStatus('NO RESERVE AMMO', 1);
        tone(120, .08, 'square', .035);
        return;
      }
      runtime.reloadWeaponId = weaponId;
      runtime.reloadStartedAt = runtime.now;
      runtime.reloadUntil = runtime.now + definition.reloadDuration;
      setStatus(`RELOADING ${definition.label.toUpperCase()}`, definition.reloadDuration);
      tone(220, .12, 'triangle', .04);
    };
    runtime.reload = reload;
    const shoot = (aimPoint = new THREE.Vector2(0, 0)) => {
      const weaponId = runtime.selectedWeaponId;
      const definition = WEAPON_DEFINITIONS[weaponId];
      if (modeRef.current !== 'playing' || runtime.nextShot > runtime.now) return;
      if (runtime.reloadUntil > runtime.now && runtime.reloadWeaponId === weaponId) return;
      if (runtime.player.magazines[weaponId] <= 0) {
        if (runtime.player.reserveAmmo[weaponId] > 0) {
          setStatus('MAGAZINE EMPTY // AUTO RELOAD', 1.1);
          reload();
        } else setStatus('MAGAZINE EMPTY // NO RESERVE AMMO', 1.1);
        tone(120, .08, 'square', .035);
        return;
      }
      runtime.player.magazines[weaponId] -= 1;
      runtime.nextShot = runtime.now + definition.fireInterval;
      runtime.recoil = definition.recoil;
      runtime.shake = Math.max(.045, definition.recoil * .42);
      const muzzle = runtime.flash;
      const muzzleLight = runtime.flashLight;
      muzzle.visible = true;
      muzzleLight.intensity = 7;
      window.setTimeout(() => { muzzle.visible = false; muzzleLight.intensity = 0; }, 48);
      tone(weaponId === 'sniper' || weaponId === 'shotgun' ? 74 : weaponId === 'minigun' ? 112 : 88, .1, 'sawtooth', .08);
      tone(weaponId === 'smg' || weaponId === 'minigun' ? 310 : 420, .055, 'square', .045);
      noise(weaponId === 'shotgun' || weaponId === 'sniper' ? .13 : .08, .025);
      if (runtime.player.magazines[weaponId] === 0 && runtime.player.reserveAmmo[weaponId] > 0) reload();

      runtime.camera.updateMatrixWorld(true);
      const origin = new THREE.Vector3();
      runtime.camera.getWorldPosition(origin);
      const livingEnemies = runtime.enemies.filter((enemy) => enemy.state !== 'dying');
      const hitCounts = new Map<EnemyUnit, { pellets: number; headshots: number }>();
      const hitObjects = livingEnemies.flatMap((enemy) => [enemy.body, enemy.rig.head]);
      let tracerDirection = new THREE.Vector3(0, 0, -1);
      let tracerDistance = definition.range;
      for (let pellet = 0; pellet < definition.pellets; pellet += 1) {
        const spreadX = (Math.random() * 2 - 1) * definition.spread;
        const spreadY = (Math.random() * 2 - 1) * definition.spread;
        const ray = new THREE.Raycaster();
        ray.far = definition.range;
        ray.setFromCamera(new THREE.Vector2(clamp(aimPoint.x + spreadX, -1, 1), clamp(aimPoint.y + spreadY, -1, 1)), runtime.camera);
        const direction = ray.ray.direction.clone().normalize();
        if (pellet === 0) tracerDirection.copy(direction);
        let target: EnemyUnit | undefined;
        let headshot = false;
        let bestDistance = definition.range + 0.001;

        const bodyHits = ray.intersectObjects(hitObjects, false);
        if (bodyHits.length > 0) {
          const hitObject = bodyHits[0].object;
          target = livingEnemies.find((enemy) => enemy.body === hitObject || enemy.rig.head === hitObject);
          bestDistance = bodyHits[0].distance;
          headshot = Boolean(target && target.rig.head === hitObject);
        }

        for (const enemy of livingEnemies) {
          const definitionForEnemy = ENEMY_DEFINITIONS[enemy.kind];
          const bodyCenter = enemy.group.position.clone();
          bodyCenter.y += definitionForEnemy.aimHeight;
          const bodyToEnemy = bodyCenter.clone().sub(origin);
          const bodyAlong = bodyToEnemy.dot(direction);
          if (bodyAlong >= 0 && bodyAlong <= definition.range && bodyAlong < bestDistance) {
            const closest = origin.clone().add(direction.clone().multiplyScalar(bodyAlong));
            if (closest.distanceTo(bodyCenter) < definitionForEnemy.hitRadius) {
              target = enemy;
              headshot = false;
              bestDistance = bodyAlong;
            }
          }

          const headCenter = new THREE.Vector3();
          enemy.rig.head.getWorldPosition(headCenter);
          const headToEnemy = headCenter.clone().sub(origin);
          const headAlong = headToEnemy.dot(direction);
          if (headAlong >= 0 && headAlong <= definition.range && headAlong < bestDistance) {
            const closest = origin.clone().add(direction.clone().multiplyScalar(headAlong));
            if (closest.distanceTo(headCenter) < .31) {
              target = enemy;
              headshot = true;
              bestDistance = headAlong;
            }
          }
        }

        if (pellet === 0) tracerDistance = Math.min(definition.range, bestDistance);
        if (target) {
          const hit = hitCounts.get(target) ?? { pellets: 0, headshots: 0 };
          hit.pellets += 1;
          if (headshot) hit.headshots += 1;
          hitCounts.set(target, hit);
        }
      }

      const tracerGeometry = new THREE.BufferGeometry().setFromPoints([
        origin,
        origin.clone().add(tracerDirection.multiplyScalar(tracerDistance)),
      ]);
      const tracerMaterial = new THREE.LineBasicMaterial({ color: definition.tracerColor, transparent: true, opacity: .68 });
      const tracer = new THREE.Line(tracerGeometry, tracerMaterial);
      scene.add(tracer);
      window.setTimeout(() => {
        scene.remove(tracer);
        tracerGeometry.dispose();
        tracerMaterial.dispose();
      }, 52);

      if (hitCounts.size === 0) {
        setStatus('SHOT // NO CONTACT', .35);
        return;
      }

      runtime.hitAt = runtime.now;
      setHitTick((value) => value + 1);
      runtime.score += 12 * [...hitCounts.values()].reduce((sum, hit) => sum + hit.pellets, 0);
      runtime.shake = Math.max(runtime.shake, definition.recoil * .72);
      tone(260, .08, 'triangle', .055);
      hitCounts.forEach((hit, target) => {
        if (target.state === 'dying') return;
        const damage = definition.damage * (hit.pellets + hit.headshots * (definition.headshotMultiplier - 1));
        target.hp = clamp(target.hp - damage, 0, target.maxHp);
        updateHealthBar(target);
        if (target.hp <= 0) {
          target.state = 'dying';
          target.deathAt = runtime.now;
          runtime.combo = runtime.now < runtime.comboUntil ? Math.min(9, runtime.combo + 1) : 1;
          runtime.comboUntil = runtime.now + 3.5;
          runtime.score += ENEMY_DEFINITIONS[target.kind].score * runtime.combo;
          setStatus(`${ENEMY_DEFINITIONS[target.kind].label} NEUTRALIZED // +${runtime.combo}X`, 1.2);
          noise(.22, .05);
          if (seeded(target.seed * 17 + runtime.wave) > .62) {
            const kind: PickupKind = seeded(target.seed * 23) > .66 ? 'health' : seeded(target.seed * 29) > .5 ? 'ammo' : 'speed';
            createPickup(target.group.position, kind);
          }
        } else {
          const hitLabel = hit.headshots > 0 ? 'HEADSHOT' : 'IMPACT CONFIRMED';
          setStatus(`${hitLabel} // ${Math.ceil(target.hp)} HP REMAINING`, .7);
        }
      });
    };
    runtime.startAudio = startAudio;
    const onKeyDown = (event: KeyboardEvent) => {
      runtime.keys[event.code] = true;
      if (event.code === 'KeyR') reload();
      if (modeRef.current === 'playing' && /^Digit[1-7]$/.test(event.code)) {
        switchWeapon(WEAPON_IDS[Number(event.code.slice(-1)) - 1]);
      }
      if (['Space', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(event.code)) event.preventDefault();
    };
    const onKeyUp = (event: KeyboardEvent) => { runtime.keys[event.code] = false; };
    const onMouseDown = (event: MouseEvent) => {
      if (event.button !== 0) return;
      if (event.target instanceof Element && event.target.closest('[data-weapon-select], .touch-controls')) return;
      if (modeRef.current !== 'playing' || isMobile || !lockedRef.current) return;
      runtime.mouseDown = true;
      shoot();
    };
    const onMouseUp = (event: MouseEvent) => {
      if (event.button === 0 && !isMobile) runtime.mouseDown = false;
    };
    const onCanvasClick = () => {
      if (modeRef.current === 'playing' && document.pointerLockElement !== canvas) canvas.requestPointerLock();
    };
    const onMouseMove = (event: MouseEvent) => {
      if (!lockedRef.current || modeRef.current !== 'playing') return;
      runtime.yaw -= event.movementX * .00225;
      runtime.pitch = clamp(runtime.pitch - event.movementY * .0018, -1.32, 1.32);
    };
    const onPointerLock = () => {
      const locked = document.pointerLockElement === canvas;
      lockedRef.current = locked;
      setIsLocked(locked);
      if (!locked) {
        runtime.mouseDown = false;
        runtime.keys = {};
      }
    };
    const onResize = () => {
      camera.aspect = window.innerWidth / window.innerHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(window.innerWidth, window.innerHeight);
    };
    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup', onKeyUp);
    window.addEventListener('mousedown', onMouseDown);
    window.addEventListener('mouseup', onMouseUp);
    window.addEventListener('mousemove', onMouseMove);
    canvas.addEventListener('click', onCanvasClick);
    document.addEventListener('pointerlockchange', onPointerLock);
    window.addEventListener('resize', onResize);

    const drawMinimap = () => {
      const map = minimapRef.current;
      if (!map) return;
      const ctx = map.getContext('2d');
      if (!ctx) return;
      const size = map.width;
      ctx.clearRect(0, 0, size, size);
      ctx.fillStyle = 'rgba(9,30,35,.88)';
      ctx.fillRect(0, 0, size, size);
      ctx.strokeStyle = 'rgba(131,239,221,.18)';
      ctx.lineWidth = 1;
      for (let i = 1; i < 4; i += 1) { ctx.beginPath(); ctx.moveTo(i * size / 4, 0); ctx.lineTo(i * size / 4, size); ctx.stroke(); ctx.beginPath(); ctx.moveTo(0, i * size / 4); ctx.lineTo(size, i * size / 4); ctx.stroke(); }
      const point = (x: number, z: number) => ({ x: size / 2 + x / 19 * size / 2, y: size / 2 + z / 19 * size / 2 });
      runtime.enemies.forEach((enemy) => {
        if (enemy.state === 'dying') return;
        const definition = ENEMY_DEFINITIONS[enemy.kind];
        const p = point(enemy.group.position.x, enemy.group.position.z);
        ctx.fillStyle = definition.minimapColor;
        ctx.beginPath();
        ctx.arc(p.x, p.y, enemy.kind === 'tank' ? 3.7 : enemy.kind === 'runner' ? 2.9 : 2.4, 0, Math.PI * 2);
        ctx.fill();
      });
      ctx.fillStyle = '#83efdd';
      const player = point(runtime.player.pos.x, runtime.player.pos.z);
      ctx.beginPath(); ctx.moveTo(player.x, player.y - 5); ctx.lineTo(player.x - 3.5, player.y + 4); ctx.lineTo(player.x + 3.5, player.y + 4); ctx.closePath(); ctx.fill();
    };
    const publishHud = () => {
      const alive = runtime.enemies.filter((enemy) => enemy.state !== 'dying').length;
      const weaponId = runtime.selectedWeaponId;
      const weaponDefinition = WEAPON_DEFINITIONS[weaponId];
      const reloading = runtime.reloadUntil > runtime.now && runtime.reloadWeaponId === weaponId;
      const status = reloading ? 'RELOADING...' : runtime.statusUntil > runtime.now ? runtime.status : alive ? 'BREACH ACTIVE // ENGAGE' : 'SECTOR CLEAR';
      setHud({
        health: Math.ceil(runtime.player.health),
        ammo: runtime.player.magazines[weaponId],
        ammoCapacity: weaponDefinition.magazineSize,
        reserveAmmo: runtime.player.reserveAmmo[weaponId],
        weaponId,
        weaponLabel: weaponDefinition.label,
        wave: runtime.wave,
        score: runtime.score,
        combo: Math.max(1, runtime.combo),
        enemies: alive,
        status,
        reload: reloading,
      });
      drawMinimap();
    };

    let frame = 0;
    let lastHudPublish = -1;
    let last = performance.now();
    const animate = (time: number) => {
      frame = requestAnimationFrame(animate);
      const dt = Math.min(.045, (time - last) / 1000);
      last = time;
      runtime.now += dt;
      if (modeRef.current === 'playing' && (lockedRef.current || isMobile)) {
        const forward = new THREE.Vector3(Math.sin(runtime.yaw), 0, -Math.cos(runtime.yaw));
        const right = new THREE.Vector3(Math.cos(runtime.yaw), 0, Math.sin(runtime.yaw));
        const movement = new THREE.Vector3();
        if (runtime.keys.KeyW || runtime.keys.ArrowUp) movement.add(forward);
        if (runtime.keys.KeyS || runtime.keys.ArrowDown) movement.sub(forward);
        if (runtime.keys.KeyD || runtime.keys.ArrowRight) movement.add(right);
        if (runtime.keys.KeyA || runtime.keys.ArrowLeft) movement.sub(right);
        if (isMobile) {
          movement.add(forward.clone().multiplyScalar(runtime.touchMove.y));
          movement.add(right.clone().multiplyScalar(runtime.touchMove.x));
        }
        if (movement.lengthSq() > 0) movement.normalize();
        const sprinting = runtime.keys.ShiftLeft || runtime.keys.ShiftRight;
        const speed = (runtime.now < runtime.player.speedUntil ? 7.5 : 5.2) * (sprinting ? 1.42 : 1);
        runtime.player.pos.add(movement.multiplyScalar(speed * dt));
        runtime.player.pos.x = clamp(runtime.player.pos.x, -17.3, 17.3);
        runtime.player.pos.z = clamp(runtime.player.pos.z, -17.3, 17.3);
        if ((runtime.keys.Space || runtime.keys.KeyE) && runtime.player.grounded) { runtime.player.velocityY = 6.1; runtime.player.grounded = false; tone(180, .08, 'triangle', .02); }
        runtime.player.velocityY -= 16 * dt;
        runtime.player.pos.y += runtime.player.velocityY * dt;
        if (runtime.player.pos.y <= 0) { runtime.player.pos.y = 0; runtime.player.velocityY = 0; runtime.player.grounded = true; }
        runtime.camera.position.set(runtime.player.pos.x, runtime.player.pos.y + 1.55, runtime.player.pos.z);
        runtime.camera.rotation.set(runtime.pitch - runtime.recoil * .28, runtime.yaw, 0);
        if (runtime.mouseDown) shoot();
        if (runtime.reloadUntil > 0 && runtime.now >= runtime.reloadUntil) {
          const reloadingWeaponId = runtime.reloadWeaponId;
          if (reloadingWeaponId) {
            const definition = WEAPON_DEFINITIONS[reloadingWeaponId];
            const missingRounds = definition.magazineSize - runtime.player.magazines[reloadingWeaponId];
            const roundsLoaded = Math.min(missingRounds, runtime.player.reserveAmmo[reloadingWeaponId]);
            runtime.player.magazines[reloadingWeaponId] += roundsLoaded;
            runtime.player.reserveAmmo[reloadingWeaponId] -= roundsLoaded;
            setStatus(`${definition.label.toUpperCase()} RELOADED`, .8);
            tone(440, .1, 'triangle', .045);
          }
          runtime.reloadUntil = 0;
          runtime.reloadWeaponId = null;
        }
        if (runtime.comboUntil < runtime.now) runtime.combo = 1;

        runtime.enemies.forEach((enemy) => {
          if (enemy.state === 'dying') {
            const age = runtime.now - enemy.deathAt;
            enemy.body.rotation.z += dt * (enemy.kind === 'tank' ? 3 : -5);
            enemy.rig.leftArm.rotation.z = -0.5 - age * 2.5;
            enemy.rig.rightArm.rotation.z = 0.5 + age * 2.5;
            enemy.rig.leftLeg.rotation.x = Math.sin(age * 14) * 0.45;
            enemy.rig.rightLeg.rotation.x = -Math.sin(age * 14) * 0.45;
            enemy.group.position.y = age * .3;
            enemy.group.scale.setScalar(Math.max(0, 1 - age * 2.2));
            enemy.bar.visible = false;
            return;
          }
          const target = runtime.player.pos.clone();
          const toPlayer = target.sub(enemy.group.position);
          const distance = toPlayer.length();
          const difficulty = waveDifficulty(runtime.wave);
          const definition = ENEMY_DEFINITIONS[enemy.kind];
          if (distance < difficulty.detectionRange) enemy.state = 'chase';
          if (enemy.state === 'patrol' && enemy.group.position.distanceTo(enemy.patrol) < .7) {
            enemy.patrol.set((seeded(enemy.seed + Math.floor(runtime.now / 3)) * 2 - 1) * 13, 0, (seeded(enemy.seed * 2 + Math.floor(runtime.now / 3)) * 2 - 1) * 13);
          }
          const destination = enemy.state === 'chase' ? runtime.player.pos : enemy.patrol;
          const direction = destination.clone().sub(enemy.group.position);
          direction.y = 0;
          if (direction.lengthSq() > .1) {
            direction.normalize();
            const { speed: enemySpeed } = enemyStats(enemy.kind, runtime.wave);
            if (enemy.kind === 'runner') {
              const zigzag = Math.sin(runtime.now * 5.8 + enemy.seed) * 0.28;
              const lateralX = -direction.z;
              const lateralZ = direction.x;
              direction.x += lateralX * zigzag;
              direction.z += lateralZ * zigzag;
              direction.normalize();
            }
            enemy.group.position.add(direction.multiplyScalar(enemySpeed * dt * (distance < 1.5 ? .2 : 1)));
            enemy.group.rotation.y = Math.atan2(direction.x, direction.z);
            const gait = Math.sin(runtime.now * (enemy.kind === 'runner' ? 9 : enemy.kind === 'tank' ? 3.4 : 5.2) + enemy.seed);
            const stride = enemy.kind === 'runner' ? 0.44 : enemy.kind === 'tank' ? 0.18 : 0.29;
            enemy.rig.leftArm.rotation.x = (enemy.kind === 'walker' ? -0.48 : enemy.kind === 'runner' ? -0.18 : -0.34) + gait * stride;
            enemy.rig.rightArm.rotation.x = (enemy.kind === 'walker' ? -0.34 : enemy.kind === 'runner' ? -0.12 : -0.24) - gait * stride;
            enemy.rig.leftLeg.rotation.x = gait * stride * 0.7;
            enemy.rig.rightLeg.rotation.x = -gait * stride * 0.7;
            enemy.rig.head.rotation.z = Math.sin(runtime.now * 2.1 + enemy.seed) * 0.035;
          }
          enemy.bar.lookAt(runtime.camera.position);
          if (distance < definition.attackRange && runtime.now > enemy.attackAt) {
            const { attackCooldown, damage } = enemyStats(enemy.kind, runtime.wave);
            enemy.attackAt = runtime.now + attackCooldown;
            runtime.player.health -= damage;
            runtime.shake = .2;
            setStatus(enemy.kind === 'tank' ? 'HEAVY IMPACT // ARMOR BREACHED' : enemy.kind === 'runner' ? 'RUNNER STRIKE // CONTACT DAMAGE' : 'WALKER STRIKE // CONTACT DAMAGE', .8);
            tone(enemy.kind === 'tank' ? 74 : enemy.kind === 'runner' ? 100 : 110, .16, 'sawtooth', .06);
            noise(.11, .03);
            if (runtime.player.health <= 0) { runtime.player.health = 0; finishGame(); }
          }
        });
        runtime.enemies = runtime.enemies.filter((enemy) => {
          if (enemy.state === 'dying' && runtime.now - enemy.deathAt > .52) { removeEnemy(enemy); return false; }
          return true;
        });
        runtime.pickups = runtime.pickups.filter((pickup) => {
          pickup.group.rotation.y += dt * 1.9;
          pickup.group.position.y = .55 + Math.sin(runtime.now * 3 + pickup.group.position.x) * .1;
          if (runtime.now > pickup.expires) { scene.remove(pickup.group); return false; }
          if (pickup.group.position.distanceTo(runtime.player.pos) < 1.25) {
            if (pickup.kind === 'health') runtime.player.health = Math.min(100, runtime.player.health + 25);
            if (pickup.kind === 'ammo') {
              const weaponId = runtime.selectedWeaponId;
              const definition = WEAPON_DEFINITIONS[weaponId];
              runtime.player.magazines[weaponId] = definition.magazineSize;
              runtime.player.reserveAmmo[weaponId] = Math.min(
                definition.reserveCapacity,
                runtime.player.reserveAmmo[weaponId] + definition.magazineSize,
              );
            }
            if (pickup.kind === 'speed') runtime.player.speedUntil = runtime.now + 8;
            setStatus(pickup.kind === 'health' ? 'REPAIR CELL ACQUIRED' : pickup.kind === 'ammo' ? 'AMMO CACHE ACQUIRED' : 'OVERDRIVE ONLINE // 08 SEC', 1.2);
            tone(pickup.kind === 'speed' ? 660 : 520, .16, 'triangle', .05);
            scene.remove(pickup.group);
            return false;
          }
          return true;
        });
        if (runtime.enemies.length === 0) {
          if (runtime.waveDelay === 0) { runtime.waveDelay = runtime.now + 2.2; setStatus('SECTOR CLEAR // NEXT BREACH INBOUND', 2.2); }
          else if (runtime.now >= runtime.waveDelay) { runtime.wave += 1; spawnWave(); }
        }
        runtime.recoil *= Math.max(0, 1 - dt * 13);
        runtime.shake *= Math.max(0, 1 - dt * 12);
        const swapProgress = clamp((runtime.now - runtime.weaponSwitchAt) / .24, 0, 1);
        const switchDip = Math.sin(swapProgress * Math.PI) * .2;
        const reloadProgress = runtime.reloadUntil > runtime.now && runtime.reloadWeaponId === runtime.selectedWeaponId
          ? clamp((runtime.now - runtime.reloadStartedAt) / WEAPON_DEFINITIONS[runtime.selectedWeaponId].reloadDuration, 0, 1)
          : 0;
        const reloadDip = Math.sin(reloadProgress * Math.PI) * .14;
        runtime.weapon.position.x = .39 + (seeded(Math.floor(runtime.now * 90)) - .5) * runtime.shake * .28;
        runtime.weapon.position.y = -.31 - runtime.recoil * .18 - switchDip - reloadDip;
        runtime.weapon.rotation.z = -.06 - runtime.recoil * .3;
        runtime.flashLight.intensity *= Math.max(0, 1 - dt * 30);
      }
      renderer.render(scene, camera);
      if (runtime.now - lastHudPublish > .12) {
        lastHudPublish = runtime.now;
        publishHud();
      }
    };
    animate(performance.now());

    return () => {
      cancelAnimationFrame(frame);
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('keyup', onKeyUp);
      window.removeEventListener('mousedown', onMouseDown);
      window.removeEventListener('mouseup', onMouseUp);
      window.removeEventListener('mousemove', onMouseMove);
      canvas.removeEventListener('click', onCanvasClick);
      document.removeEventListener('pointerlockchange', onPointerLock);
      window.removeEventListener('resize', onResize);
      if (runtime.audio) { runtime.audio.close(); }
      Object.values(weaponModels).forEach((view) => view.dispose());
      zombieFactory.dispose();
      renderer.dispose();
      runtimeRef.current = null;
    };
  }, [isMobile]);

  const startGame = useCallback(() => {
    const runtime = runtimeRef.current;
    if (!runtime) {
      setWebglUnavailable(true);
      return;
    }
    runtime.startAudio?.();
    runtime.resetGame?.();
    modeRef.current = 'playing';
    setMode('playing');
      if (isMobile) {
        lockedRef.current = true;
        setIsLocked(true);
      } else {
        runtime.canvas.requestPointerLock();
      }
  }, [isMobile]);
  const restartGame = useCallback(() => {
    startGame();
  }, [startGame]);

  const healthPercent = clamp(hud.health, 0, 100);
  const beginTouchMove = (event: ReactPointerEvent<HTMLDivElement>) => {
    event.currentTarget.setPointerCapture(event.pointerId);
    moveOriginRef.current = { x: event.clientX, y: event.clientY };
  };
  const updateTouchMove = (event: ReactPointerEvent<HTMLDivElement>) => {
    const dx = clamp((event.clientX - moveOriginRef.current.x) / 42, -1, 1);
    const dy = clamp((event.clientY - moveOriginRef.current.y) / 42, -1, 1);
    if (runtimeRef.current) runtimeRef.current.touchMove = { x: dx, y: -dy };
  };
  const endTouchMove = () => {
    if (runtimeRef.current) runtimeRef.current.touchMove = { x: 0, y: 0 };
  };
  const updateTouchAim = (event: ReactPointerEvent<HTMLDivElement>) => {
    const dx = event.clientX - aimPointRef.current.x;
    const dy = event.clientY - aimPointRef.current.y;
    aimPointRef.current = { x: event.clientX, y: event.clientY };
    const runtime = runtimeRef.current;
    if (!runtime || modeRef.current !== 'playing') return;
    runtime.yaw -= dx * .005;
    runtime.pitch = clamp(runtime.pitch - dy * .004, -1.32, 1.32);
  };
  const handleFireDown = () => { if (runtimeRef.current) runtimeRef.current.mouseDown = true; };
  const handleFireUp = () => { if (runtimeRef.current) runtimeRef.current.mouseDown = false; };
  const handleJump = () => {
    if (!runtimeRef.current) return;
    runtimeRef.current.keys.Space = true;
    window.setTimeout(() => { if (runtimeRef.current) runtimeRef.current.keys.Space = false; }, 120);
  };
  const handleReload = () => {
    runtimeRef.current?.reload?.();
  };
  return (
    <main className="game-shell" data-testid="game-shell">
      <canvas ref={canvasRef} className="game-canvas" data-testid="game-canvas" />
      <div className="screen-vignette" />
      {mode === 'start' && (
        <section className="start-screen" data-testid="screen-start">
          <div className="start-card">
            <div className="eyebrow">TACTICAL SIMULATION / SECTOR 07</div>
            <h1 className="brand-title">Neon <span>Breach</span></h1>
            <p className="start-subtitle">A short-form first-person survival drill. Read the room, break the rush, and keep the corridor yours for one more wave.</p>
            <div className="start-meta">
              <span className="meta-chip">WASD move</span>
              <span className="meta-chip">Mouse aim</span>
              <span className="meta-chip">LMB fire</span>
              <span className="meta-chip">R reload</span>
              <span className="meta-chip">1–7 weapons</span>
              <span className="meta-chip">Shift sprint</span>
              {isMobile && <span className="meta-chip">Touch controls</span>}
            </div>
            <button className="primary-button" onClick={startGame} data-testid="button-play">Enter the breach</button>
            <p className="start-help">
              {webglUnavailable
                ? <><b>WebGL unavailable.</b> Enable hardware acceleration or open this in a WebGL-capable browser.</>
                : isMobile
                  ? <><b>Touch ready.</b> Drag the left pad to move and the right side to aim.</>
                  : <><b>Desktop.</b> Pointer lock will engage when the drill begins.</>}
            </p>
          </div>
        </section>
      )}
      {mode === 'playing' && (
        <section className="hud" data-testid="hud-game">
          <div className="hud-top">
            <div className="wave-readout"><span className="hud-label">Wave / contacts</span><span className="hud-value" data-testid="hud-wave">{String(hud.wave).padStart(2, '0')} <small style={{ fontSize: 13, color: '#83a7a6' }}>{hud.enemies}</small></span></div>
            <div className="combo-readout"><span className="hud-label">Combo</span><span className="hud-value" data-testid="hud-combo">{hud.combo}X</span></div>
            <div className="score-readout"><span className="hud-label">Score</span><span className="hud-value" data-testid="hud-score">{hud.score.toLocaleString()}</span></div>
          </div>
          <div className="minimap-wrap"><canvas className="minimap" ref={minimapRef} width="124" height="124" data-testid="hud-minimap" /></div>
          <div className="crosshair"><span className="crosshair-dot" /></div>
          <div className={`hit-marker ${hitTick ? 'active' : ''}`} key={hitTick} data-testid="feedback-hit-marker">×</div>
          <div className="weapon-loadout" role="group" aria-label="Choose weapon">
            {WEAPON_IDS.map((weaponId) => {
              const definition = WEAPON_DEFINITIONS[weaponId];
              const selected = hud.weaponId === weaponId;
              return (
                <button
                  key={weaponId}
                  type="button"
                  className={`weapon-choice${selected ? ' selected' : ''}`}
                  aria-label={`Switch to ${definition.label}, key ${definition.key}`}
                  aria-pressed={selected}
                  title={`${definition.label} · ${definition.key}`}
                  data-weapon-select={weaponId}
                  data-testid={`weapon-select-${weaponId}`}
                  onClick={() => runtimeRef.current?.switchWeapon?.(weaponId)}
                >
                  <span className="weapon-key">{definition.key}</span>
                  <span className="weapon-name">{definition.shortLabel}</span>
                </button>
              );
            })}
          </div>
          <div className="hud-bottom">
            <div className="health-block">
              <div className="health-row"><span className="hud-label">Suit integrity</span><span className="health-number" data-testid="hud-health">{hud.health}%</span></div>
              <div className="health-track"><div className="health-fill" style={{ width: `${healthPercent}%` }} /></div>
              <div className="status-text" data-testid="hud-status">{hud.status}</div>
            </div>
            <div className="ammo-block">
              <div className="ammo-value" data-testid="hud-ammo">{String(hud.ammo).padStart(2, '0')}<span> / {hud.ammoCapacity}</span></div>
              <div className="ammo-caption" data-testid="hud-ammo-caption">
                {hud.reload ? 'RELOADING' : `${hud.weaponLabel.toUpperCase()} // ${hud.reserveAmmo} RESERVE`}
              </div>
            </div>
          </div>
          {!isLocked && <div className="lock-prompt" data-testid="status-pointer-lock">Click the arena to resume</div>}
          {!isLocked && <div className="pause-chip" data-testid="status-paused">Paused</div>}
          {isMobile && (
            <div className="touch-controls" data-testid="touch-controls">
              <div
                className="touch-aim-zone"
                onPointerDown={(event) => {
                  event.currentTarget.setPointerCapture(event.pointerId);
                  aimPointRef.current = { x: event.clientX, y: event.clientY };
                }}
                onPointerMove={updateTouchAim}
                data-testid="touch-aim-zone"
              />
              <div
                className="touch-joystick"
                onPointerDown={beginTouchMove}
                onPointerMove={updateTouchMove}
                onPointerUp={endTouchMove}
                onPointerCancel={endTouchMove}
                data-testid="touch-move"
              >
                <div className="touch-stick" />
              </div>
              <button className="touch-action touch-fire" onPointerDown={handleFireDown} onPointerUp={handleFireUp} onPointerCancel={handleFireUp} data-testid="touch-fire">FIRE</button>
              <button className="touch-action touch-jump" onPointerDown={handleJump} data-testid="touch-jump">JUMP</button>
              <button className="touch-action touch-reload" onPointerDown={handleReload} data-testid="touch-reload">R</button>
            </div>
          )}
        </section>
      )}
      {mode === 'over' && (
        <section className="game-over" data-testid="screen-game-over">
          <div className="game-over-card">
            <div className="eyebrow">SIGNAL LOST / RUN TERMINATED</div>
            <h2 className="game-over-title">Breach failed</h2>
            <div className="final-score">Final score<strong data-testid="final-score">{hud.score.toLocaleString()}</strong></div>
            <div className="start-meta" style={{ justifyContent: 'center' }}><span className="meta-chip">Wave {String(hud.wave).padStart(2, '0')}</span><span className="meta-chip">Combo {hud.combo}X</span></div>
            <button className="primary-button" onClick={restartGame} data-testid="button-restart">Run it back</button>
          </div>
        </section>
      )}
    </main>
  );
}

export default App;