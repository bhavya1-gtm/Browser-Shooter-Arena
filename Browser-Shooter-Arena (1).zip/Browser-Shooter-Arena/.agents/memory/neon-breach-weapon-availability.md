---
name: Neon Breach weapon availability
description: Intentional access policy for the web game's seven-weapon loadout.
---

All seven weapons are selectable from wave one, with the pistol as the default. Their roles come from different damage, cadence, spread, range, recoil, magazine, and reserve tradeoffs rather than wave locks.

**Why:** The request was to give players tools that can answer escalating threats, while a currency and unlock system has not been built. Gating the stronger options would leave players without those choices during the waves that need them.

**How to apply:** Keep the full loadout available when extending combat. Add unlock gates only if the user explicitly chooses a progression or economy system.