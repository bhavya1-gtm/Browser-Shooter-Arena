---
name: pnpm patch-commit comment retention
description: pnpm patch commits can rewrite workspace YAML and discard comments.
---

After running `pnpm patch-commit`, inspect `pnpm-workspace.yaml`: pnpm may reserialize the file and remove explanatory comments while preserving the configuration values.

**Why:** Important policy explanations can disappear even when the settings themselves remain unchanged.

**How to apply:** Restore essential comments after patch commit, and avoid rerunning patch commit solely to preserve YAML formatting.