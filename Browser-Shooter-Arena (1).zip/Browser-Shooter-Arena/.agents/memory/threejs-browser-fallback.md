---
name: Three.js browser fallback
description: Environment notes for browser-based Three.js artifacts and preview verification.
---

Three.js can load correctly while the preview browser still cannot create a WebGL context. Treat WebGL initialization as a recoverable capability check and keep the surrounding UI usable.

**Why:** A missing or unavailable WebGL context otherwise throws during renderer construction, causing the whole React surface to fall into an error state and making start actions appear inert.

**How to apply:** Wrap renderer creation in a guarded initialization path, surface a clear WebGL/hardware-acceleration message when unavailable, and verify the game in a WebGL-capable browser for the full 3D path.